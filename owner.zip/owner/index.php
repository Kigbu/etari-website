<?php
require_once('../core/init.php');
//print_r($_SESSION);exit;
include_once('view/layouts/template.php');
?>