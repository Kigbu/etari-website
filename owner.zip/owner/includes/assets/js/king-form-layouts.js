$(document).ready(function(){

	/* intentionally created on separated js file for the next theme updates */

	/************************
	/*	SELECT DROPDOWN
	/************************/

	$('.select-ticket-type, .select-ticket-priority').multiselect();

});